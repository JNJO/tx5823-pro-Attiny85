#tx5823 SPI modification
In order to get the tx5823 to use SPI you will need to open it and remove a single SMD resistor.

![alt text](img/tx5823-spi-mod.jpg)
